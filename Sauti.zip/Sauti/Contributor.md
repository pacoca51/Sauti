Contributors of Easer
======

I'd like to say thank you to these guys who contributed to Easer.  
Thanks a lot :)

# People who contributed to the app function and/or UI and/or test
* AlaskaLinuxUser <https://github.com/alaskalinuxuser>
* Danielsan <https://github.com/trikaphundo>
* Sohalt <https://github.com/Sohalt>
* DeathTickle (Léopold Delouche) <https://github.com/DeathTickle>

# People who contributed to translation and/or documentation
* naofum <https://github.com/naofum>
* NPN (Ryan Huang) <https://github.com/NPN>
* twikedk (Ole Carlsen) <https://github.com/twikedk>

