package ryey.easer.core.data;

public interface WithCreatedVersion {
    int createdVersion();
}
